<?php
header("Content-Type: application/json");
header("charset=utf-8");
header("Access-Control-Allow-Origin: *");

date_default_timezone_set('UTC');//Set UTC
$date = new DateTime();

$response = [
    "protocol" => "EpochLink",
    "version" => "1.0.0",
    "address" => (empty($_SERVER['HTTPS']) ? 'http://' : 'https://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
    "time_zone" => date_default_timezone_get(),
    "iso8601_time" => $date->format(DateTime::ATOM),
    "unix_time_ms" => $date->getTimestamp() * 1000 + round($date->format('u') / 1000),
    "unix_time" => (int)$date->format('U')
];

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>