//Warning!!! node.js hissu!!!
var port = 8080

var http = require('http');
var server = http.createServer(function(request, response){
    response.writeHead(200,{'Content-Type': 'application/json; charset=utf-8'},{'Access-Control-Allow-Origin': '*'});
    var now = new Date();
    time_json = {
        "protocol": "EpochLink",
        "version": "1.0.0",
        "address": request.protocol + '://' + request.headers.host + request.url,
        "time_zone": "UTC",
        "iso8601_time": now.toISOString(),
        "unix_time_ms": now.getTime(),
        "unix_time": Math.floor(now.getTime() / 1000)
    }
    response.end(JSON.stringify(time_json));
})
server.listen(port);
console.log("Serving on port "+port+"...");