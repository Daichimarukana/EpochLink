EpochLink v1.0.0のサーバープログラムです。
JS,php,Py、どのサーバーも、公開する際は、正確な時刻を発信できるよう調整することを推奨します。
ここにあるサーバープログラムは、すべてサーバープログラムを動作させているコンピューターの時刻に基づき、動作しています。
※EpochLinkサーバーからEpochLinkサーバーへ時刻の共有を行い、同期することは推奨しません。
コンピューターに搭載されている時計がよほど高精度でない限り、定期的に信頼できる時計(NTPなど)から同期をすることをお勧めします。

以下の各言語でのサーバープログラムの動作方法を記載しているのでここにあるコードをそのまま使用してEpochLinkサーバーを構築する際はご参考にどうぞ！

---[Node.js]---
Node.jsで動作させる方は、このフォルダ内でコンソールより、""内のコマンドを実行することでサーバーの構築が可能です。

"node server.js"

---[php]---
phpで動作させる方は、phpが導入済みの環境で、Apacheやnginxで指定したサーバーのディレクトリ内にserver.phpを適切に配置し、Apacheやnginxなどのサーバーソフトウェアを起動してください。

---[python]---
pythonで動作させる方は、このフォルダ内でコンソールより、""内のコマンドを実行することでサーバーの構築が可能です。

"python server.py"



サーバープログラムはすべてNYSLライセンスです。
同梱されているLicense.txtをご確認ください。



Made by daichimarukana
TwitterID: @daichimarukana
E-Mail: daichimarukana@gmail.com
WebSite: daichimarukana.com