import time
import requests

url = "https://elp.example.com/"#EpochLinkServer Address [Example](http://localhost:3000/)

start_get_dt = int(time.time() * 1000)

response = requests.get(url)
json_data = response.json()

end_get_dt = int(time.time() * 1000)

now_unix_ms = json_data["unix_time_ms"] + ((end_get_dt - start_get_dt) / 2)

print(time.strftime('%Y/%m/%d %H:%M:%S', time.gmtime(now_unix_ms // 1000)))