from wsgiref.simple_server import make_server
import json
import datetime
import time

port = 8080

def timejson(port):
    now = datetime.datetime.now(datetime.timezone.utc)#UTC Date

    timedata = {
        "protocol": "EpochLink",
        "version": "1.0.0",
        "address": "http://localhost:"+str(port)+"/",
        "time_zone": "UTC",
        "iso8601_time": now.isoformat(timespec='seconds'),
        "unix_time_ms": int(time.time() * 1000),
        "unix_time": int(time.time())
    }
    return timedata

def app(environ, start_response):
    status = '200 OK'
    headers = [
        ('Content-type', 'application/json; charset=utf-8'),
        ('Access-Control-Allow-Origin', '*'),
    ]
    start_response(status, headers)

    return [json.dumps(timejson(port)).encode("utf-8")]

with make_server('', port, app) as httpd:
    print("Serving on port "+str(port)+"...")
    httpd.serve_forever()