<?php
date_default_timezone_set('UTC');//Set UTC

$start_get_dt = (int)substr(str_replace('.', '', microtime(true)),0,13);//Get Start Time

$url = "https://elp.example.com/";//EpochLinkServer Address [Example](http://localhost/example/php/server/server.php)
$json = file_get_contents($url);

$end_get_dt = (int)substr(str_replace('.', '', microtime(true)),0,13);//Get End Time

$data = json_decode($json, true);
$now_unix_ms = $data["unix_time_ms"] + (($end_get_dt - $start_get_dt) / 2);

echo date('Y/m/d H:i:s', (int)substr($now_unix_ms,0,10));
?>